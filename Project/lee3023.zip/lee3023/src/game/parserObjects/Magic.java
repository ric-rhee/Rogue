package game.parserObjects;
import game.Char;
import game.ObjectDisplayGrid;

public class Magic extends Displayable {

    public void drawObject(ObjectDisplayGrid displayGrid) {
    }
}
