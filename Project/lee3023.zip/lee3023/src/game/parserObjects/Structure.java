package game.parserObjects;

public abstract class Structure extends Displayable {
    public Structure() {
        super();
    }
}
