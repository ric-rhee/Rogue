package src;

public class CreatureAction {
    private Creature owner;

    public CreatureAction(Creature _owner) {
        owner = _owner;
    }
}
