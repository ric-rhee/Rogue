package src;

public class Dungeon {
    private String name;
    private int width;
    private int gameHeight;

    public Dungeon(String _name, int _width, int _gameHeight) {
        name = _name;
        width = _width;
        gameHeight = _gameHeight;
    }

    public void getDungeon(String _name, int _width, int _gameHeight) {
        name = _name;
        width = _width;
        gameHeight = _gameHeight;
    }

    public void addRoom(Room room) {
    }

    public void addCreature(Creature creature) {
    }

    public void addPassage(Passage passage) {
    }

    public void addItem(Item item) {
    }
}
