package src;

public class Item extends Displayable {
    private Creature owner;
}
