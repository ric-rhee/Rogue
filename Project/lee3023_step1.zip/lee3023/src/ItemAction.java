package src;

public class ItemAction extends Displayable {
    private Item owner;

    public ItemAction(Item _owner) {
        owner = _owner;
    }
}
