package src;

public class ObjectDisplayGrid {
    private int gameHeight;
    private int width;
    private int topHeight;

    public void getObjectDisplayGrid(int gameHeight, int width, int topHeight) {

    }

    public void setTopMessageHeight(int topHeight) {

    }
}
